package com.maruf.assistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var selectedVideoName = "কোনো ভিডিও সিলেক্ট করা হয়নি"
    private lateinit var topic: EditText
    private lateinit var titleField: EditText
    private lateinit var descriptionField: EditText
    private lateinit var hashtagsField: EditText
    private lateinit var videoStatus: TextView

    private val pickVideo = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(28))
            setBackgroundColor(0xFFF7F8FC.toInt())
        }
        val scroll = ScrollView(this)
        scroll.addView(root)

        root.addView(label("MARUF AI ASSISTANT", 25f, true))
        root.addView(label("তোমার ব্যক্তিগত YouTube সহকারী • Version 1.0", 14f, false))
        root.addView(space(14))
        root.addView(label("১. ভিডিও বেছে নাও", 18f, true))
        videoStatus = label(selectedVideoName, 14f, false)
        root.addView(videoStatus)
        root.addView(button("ফোন থেকে ভিডিও সিলেক্ট করো") { chooseVideo() })
        root.addView(space(10))
        root.addView(label("২. ভিডিওর গল্প/বিষয় লিখো", 17f, true))
        topic = edit("যেমন: গরিব Maruf পরিশ্রম করে সফল হলো")
        root.addView(topic)
        root.addView(button("টাইটেল ও ডেসক্রিপশনের খসড়া তৈরি করো") { makeDraft() })
        root.addView(space(8))
        root.addView(label("YouTube Title", 15f, true))
        titleField = edit("ভিডিওর টাইটেল")
        root.addView(titleField)
        root.addView(label("Description", 15f, true))
        descriptionField = edit("ভিডিওর বিবরণ")
        descriptionField.minLines = 4
        root.addView(descriptionField)
        root.addView(label("Hashtags", 15f, true))
        hashtagsField = edit("#Shorts #BanglaStory #AIvideo")
        root.addView(hashtagsField)
        root.addView(space(8))
        root.addView(button("সব লেখা কপি/শেয়ার করো") { shareMetadata() })
        root.addView(button("YouTube খুলে আপলোড করো") { openYouTube() })
        root.addView(space(12))
        root.addView(label("এখনকার সংস্করণের সীমা", 16f, true))
        root.addView(label("এই প্রথম সংস্করণ ভিডিওটি নিজে এডিট বা YouTube-এ সরাসরি আপলোড করে না। এটি ভিডিও বেছে নিতে, কনটেন্টের খসড়া তৈরি করতে এবং লেখা শেয়ার করতে পারে। পরের ধাপে সাবটাইটেল/ভিডিও প্রসেসিং ও অনুমোদিত YouTube API সংযোগ যোগ করতে হবে।", 14f, false))
        root.addView(space(10))
        root.addView(label("নিরাপত্তা: Google পাসওয়ার্ড বা API key এই অ্যাপে লিখবে না।", 13f, true))

        setContentView(scroll)
    }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, pickVideo)
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility in this starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideo && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                selectedVideoName = uri.lastPathSegment ?: "ভিডিও সিলেক্ট করা হয়েছে"
                videoStatus.text = "ভিডিও সিলেক্ট হয়েছে: $selectedVideoName"
                Toast.makeText(this, "ভিডিও সিলেক্ট হয়েছে।", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun makeDraft() {
        val idea = topic.text.toString().trim().ifBlank { "একটি অনুপ্রেরণামূলক বাংলা গল্প" }
        titleField.setText("$idea | বাংলা AI Shorts #Shorts".take(95))
        descriptionField.setText(
            "একটি ছোট বাংলা AI গল্প: $idea\n\n" +
            "গল্পটি ভালো লাগলে Maruf Zero To Hero চ্যানেলটি সাবস্ক্রাইব করে পাশে থাকুন।\n" +
            "ভিডিওটি AI-সহায়তায় তৈরি।\n\n" +
            "#BanglaStory #ZeroToHero #AIShorts"
        )
        hashtagsField.setText("#Shorts #BanglaStory #ZeroToHero #AIShorts")
        Toast.makeText(this, "প্রাথমিক খসড়া তৈরি হয়েছে—প্রকাশের আগে যাচাই করো।", Toast.LENGTH_LONG).show()
    }

    private fun shareMetadata() {
        val all = "Title:\n${titleField.text}\n\nDescription:\n${descriptionField.text}\n\nHashtags:\n${hashtagsField.text}"
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, all)
        }
        startActivity(Intent.createChooser(send, "Maruf AI Assistant থেকে লেখা শেয়ার করো"))
    }

    private fun openYouTube() {
        val intent = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
        if (intent != null) startActivity(intent) else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://m.youtube.com/upload")))
        Toast.makeText(this, "YouTube-এ ভিডিও, লেখা ও থাম্বনেইল নিজে যাচাই করে প্রকাশ করো।", Toast.LENGTH_LONG).show()
    }

    private fun label(text: String, size: Float, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(if (bold) 0xFF182033.toInt() else 0xFF555D70.toInt())
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun edit(hintText: String): EditText = EditText(this).apply {
        hint = hintText
        textSize = 15f
        setTextColor(0xFF182033.toInt())
        setHintTextColor(0xFF8A90A0.toInt())
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(0xFFFFFFFF.toInt())
            setCornerRadius(dp(12).toFloat())
            setStroke(dp(1), 0xFFD9DEEA.toInt())
        }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(4); bottomMargin = dp(10)
        }
    }

    private fun button(text: String, action: () -> Unit): Button = Button(this).apply {
        this.text = text
        isAllCaps = false
        textSize = 15f
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(5); bottomMargin = dp(5)
        }
    }

    private fun space(height: Int) = TextView(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
